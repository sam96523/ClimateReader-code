	
package com.basics.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.basics.model.Admin;


@Repository
public interface AdminRepository extends CrudRepository<Admin,Integer>{

	Admin findByEmail(String email);

	@Query("select a from Admin a where a.email = :email and a.password = :password and a.adm= :adm")
	
	public Admin findByEmailAndPassword(@Param("email") String email, @Param("password") String password,@Param("adm")  String adm);
}
