package com.basics.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.basics.dao.UserRepository;
import com.basics.model.User;

@Controller
public class UserController {
	@Autowired
	private UserRepository userRepository;
//-------------------REGISTER HANDLER---------------------------   
	@RequestMapping("/register")
	public String showForm(Model model) {
		return "register";
	}
	
	@RequestMapping(path = "/do_register",method=RequestMethod.POST)
	public String handleForm(@ModelAttribute User user, Model model) {
		User u = null;
	    u = this.userRepository.findByEmail(user.getEmail());
		if(u != null) {
			model.addAttribute("message", "This email is already exist");
			return "register";
		}else {
		    this.userRepository.save(user);
		    return "login";
		}	
	}
//---------------------LOGIN HANDLER--------------------------------
	@RequestMapping("/login")
	public String login(Model model) {
		return "login";
	}
	@RequestMapping(path="/do_login",method=RequestMethod.GET)
	public String login(@ModelAttribute User user,Model model) {
		User u=null;
		User email = this.userRepository.findByEmail(user.getEmail());
	
	
		if(email == null) {
			model.addAttribute("message", "Email does not exist");
			return "login";
		}else {
			u = this.userRepository.findByEmailAndPassword(user.getEmail(), user.getPassword());
			 if(u == null) {
				 model.addAttribute("message", "Bad credentials");
				 return "login";
			 }else {
				 
					 return "newpage";
				 }
		}
	}	
	 @RequestMapping("/all")
	  public  String getAllUsers(Model model) {
	    // This returns a JSON or XML with the users
	    List<User> list=new ArrayList<User>();
	    list=(List<User>)userRepository.findAll();
	    model.addAttribute("list",list);
	    /*Iterator<UserData> itr=userRepository.findAll();
	     * itr.forEach(User)
	     * List<User> lst=(List<User>)userRepository.findAll();
	     * fro(int i=0;i<lst.size();i++)
	     *   System.out.println(lst.get(i));
	     */
	    System.out.println(list);
	    return "users";
	  }
}
