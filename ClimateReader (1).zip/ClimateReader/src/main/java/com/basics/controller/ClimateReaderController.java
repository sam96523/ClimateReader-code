package com.basics.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class ClimateReaderController {


@RequestMapping("/weather")
public ModelAndView callingJSP()
{
	return new ModelAndView("weather");
}	
@RequestMapping("/weatherDay")
public ModelAndView weatherDay()
{
	return new ModelAndView("newpage");
}
@RequestMapping("/page")
public ModelAndView homePage()
{
	return new ModelAndView("home");
}

}