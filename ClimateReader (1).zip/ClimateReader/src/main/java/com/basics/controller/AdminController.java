package com.basics.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.basics.dao.AdminRepository;
import com.basics.dao.UserRepository;
import com.basics.model.Admin;
import com.basics.model.User;

@Controller
public class AdminController {
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private UserRepository userRepository;
//-------------------REGISTER HANDLER---------------------------   
	@RequestMapping("/adminRegister")
	public String showForm(Model model) {
		return "adminRegister";
	}

	@RequestMapping(path = "/post_register", method = RequestMethod.POST)
	public String handleForm(@ModelAttribute Admin admin, Model model) {
		Admin a = null;
		a = this.adminRepository.findByEmail(admin.getEmail());
		if (a != null) {
			model.addAttribute("message", "This email is already exist");
			return "adminRegister";
		} else {
			this.adminRepository.save(admin);
			return "adminLogin";
		}
	}

//---------------------LOGIN HANDLER--------------------------------
	@RequestMapping("/adminLogin")
	public String login(Model model) {
		return "adminLogin";
	}

	@RequestMapping(path = "/get_login", method = RequestMethod.GET)
	public String login(@ModelAttribute Admin admin, Model model) {
		Admin a = null;
		Admin email = this.adminRepository.findByEmail(admin.getEmail());

		if (email == null) {
			model.addAttribute("message", "Email does not exist");
			return "adminLogin";
		} else {
			a = this.adminRepository.findByEmailAndPassword(admin.getEmail(), admin.getPassword(), admin.getAdm());
			if (a == null) {
				model.addAttribute("message", "Bad credentials");
				return "adminLogin";
			} else {
				  // This returns a JSON or XML with the users
			    List<User> list=new ArrayList<User>();
			    list=(List<User>)userRepository.findAll();
			    model.addAttribute("list",list);
			    /*Iterator<UserData> itr=userRepository.findAll();
			     * itr.forEach(User)
			     * List<User> lst=(List<User>)userRepository.findAll();
			     * fro(int i=0;i<lst.size();i++)
			     *   System.out.println(lst.get(i));
			     */
			    System.out.println(list);
			    return "users";
			}
		}
	}
	
	  @RequestMapping("/allUsers") public String getAllUsers(Model model) { 
		  // This returns a JSON or XML with the users List<Admin> lists=new
			
		  List<Admin> lists = new ArrayList<Admin>();
			lists = (List<Admin>) adminRepository.findAll();
			model.addAttribute("lists", lists);
			/*
			 * Iterator<UserData> itr=userRepository.findAll(); itr.forEach(User) List<User>
			 * lst=(List<User>)userRepository.findAll(); fro(int i=0;i<lst.size();i++)
			 * System.out.println(lst.get(i));
			 */
			
	  
	  System.out.println(lists); 
	  return "admin"; }
	 
}
