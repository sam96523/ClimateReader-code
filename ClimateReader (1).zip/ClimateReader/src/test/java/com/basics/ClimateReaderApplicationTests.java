package com.basics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClimateReaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
